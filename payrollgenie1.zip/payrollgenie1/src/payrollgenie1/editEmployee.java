/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package payrollgenie1;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Kyan
 */
public class editEmployee extends javax.swing.JFrame {


    String[] employeeInfo;
    int id;
    
    public editEmployee() {
        initComponents();
        
        
        Connect();
         
        
    }
    public editEmployee(int id, String[] employeeInfo) {
        initComponents();
        Connect();
        this.employeeInfo = employeeInfo;
        this.id = id;
        initField(); 
    }
    
    public void initField() {
        labelID.setText(String.valueOf(id));
        fieldName.setText(employeeInfo[0]);
        fieldSex.setText(employeeInfo[1]);
        fieldDate.setText(employeeInfo[2]);
        fieldAddress1.setText(employeeInfo[3]);
        fieldAddress2.setText(employeeInfo[4]);
        fieldDepartment.setText(employeeInfo[5]);
        fieldPosition.setText(employeeInfo[6]);
        fieldSalary.setText(employeeInfo[7]);
        fieldTaxC1.setText(employeeInfo[8]);
        fieldTaxC2.setText(employeeInfo[9]);
        fieldTaxC3.setText(employeeInfo[10]);
        fieldTaxF1.setText(employeeInfo[11]);
        fieldTaxF2.setText(employeeInfo[12]);
        fieldTaxF3.setText(employeeInfo[13]);
    }
        
        Connection con;
        PreparedStatement pst_basic;
        PreparedStatement pst_rates;
        PreparedStatement pst_occupation;
   
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/employee_information","root","");         
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(EmployeeManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(EmployeeManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void close() {
        WindowEvent closeWindow = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
        
        EmployeeInformation EI = new EmployeeInformation(id);
        EI.setVisible(true);
        
        
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jSpinner1 = new javax.swing.JSpinner();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        buttonGroup6 = new javax.swing.ButtonGroup();
        buttonGroup7 = new javax.swing.ButtonGroup();
        buttonGroup8 = new javax.swing.ButtonGroup();
        buttonGroup9 = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnAddEmployee = new javax.swing.JButton();
        label9 = new java.awt.Label();
        label1 = new java.awt.Label();
        fieldTaxC2 = new javax.swing.JTextField();
        fieldName = new javax.swing.JTextField();
        label10 = new java.awt.Label();
        label2 = new java.awt.Label();
        fieldTaxC3 = new javax.swing.JTextField();
        label4 = new java.awt.Label();
        label11 = new java.awt.Label();
        fieldAddress1 = new javax.swing.JTextField();
        label12 = new java.awt.Label();
        label5 = new java.awt.Label();
        label13 = new java.awt.Label();
        fieldAddress2 = new javax.swing.JTextField();
        label14 = new java.awt.Label();
        label6 = new java.awt.Label();
        label15 = new java.awt.Label();
        fieldDepartment = new javax.swing.JTextField();
        label7 = new java.awt.Label();
        labelID = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        fieldPosition = new javax.swing.JTextField();
        fieldSex = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        label16 = new java.awt.Label();
        label8 = new java.awt.Label();
        fieldDate = new javax.swing.JTextField();
        fieldSalary = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        fieldTaxF1 = new javax.swing.JTextField();
        fieldTaxF3 = new javax.swing.JTextField();
        fieldTaxF2 = new javax.swing.JTextField();
        fieldTaxC1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Edit Employee");
        setBackground(new java.awt.Color(77, 85, 204));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(77, 85, 204));

        btnAddEmployee.setBackground(new java.awt.Color(239, 176, 54));
        btnAddEmployee.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnAddEmployee.setText("Edit");
        btnAddEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddEmployeeActionPerformed(evt);
            }
        });

        label9.setBackground(new java.awt.Color(77, 85, 204));
        label9.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label9.setForeground(new java.awt.Color(255, 255, 255));
        label9.setText("%");

        label1.setBackground(new java.awt.Color(77, 85, 204));
        label1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 255, 255));
        label1.setText("Name:");

        fieldTaxC2.setBackground(new java.awt.Color(181, 168, 213));
        fieldTaxC2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldTaxC2.setForeground(new java.awt.Color(255, 255, 255));

        fieldName.setBackground(new java.awt.Color(181, 168, 213));
        fieldName.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldName.setForeground(new java.awt.Color(255, 255, 255));
        fieldName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNameActionPerformed(evt);
            }
        });

        label10.setBackground(new java.awt.Color(77, 85, 204));
        label10.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label10.setForeground(new java.awt.Color(255, 255, 255));
        label10.setText("%");

        label2.setBackground(new java.awt.Color(77, 85, 204));
        label2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label2.setForeground(new java.awt.Color(255, 255, 255));
        label2.setText("Sex (M/F):");

        fieldTaxC3.setBackground(new java.awt.Color(181, 168, 213));
        fieldTaxC3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldTaxC3.setForeground(new java.awt.Color(255, 255, 255));

        label4.setBackground(new java.awt.Color(77, 85, 204));
        label4.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label4.setForeground(new java.awt.Color(255, 255, 255));
        label4.setText("Address 1:");

        label11.setBackground(new java.awt.Color(77, 85, 204));
        label11.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label11.setForeground(new java.awt.Color(255, 255, 255));
        label11.setText("%");

        fieldAddress1.setBackground(new java.awt.Color(181, 168, 213));
        fieldAddress1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldAddress1.setForeground(new java.awt.Color(255, 255, 255));

        label12.setBackground(new java.awt.Color(77, 85, 204));
        label12.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label12.setForeground(new java.awt.Color(255, 255, 255));
        label12.setText("PHP");

        label5.setBackground(new java.awt.Color(77, 85, 204));
        label5.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label5.setForeground(new java.awt.Color(255, 255, 255));
        label5.setText("Address 2:");

        label13.setBackground(new java.awt.Color(77, 85, 204));
        label13.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label13.setForeground(new java.awt.Color(255, 255, 255));
        label13.setText("PHP");

        fieldAddress2.setBackground(new java.awt.Color(181, 168, 213));
        fieldAddress2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldAddress2.setForeground(new java.awt.Color(255, 255, 255));

        label14.setBackground(new java.awt.Color(77, 85, 204));
        label14.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label14.setForeground(new java.awt.Color(255, 255, 255));
        label14.setText("PHP");

        label6.setBackground(new java.awt.Color(77, 85, 204));
        label6.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label6.setForeground(new java.awt.Color(255, 255, 255));
        label6.setText("Department:");

        label15.setBackground(new java.awt.Color(77, 85, 204));
        label15.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label15.setForeground(new java.awt.Color(255, 255, 255));
        label15.setText("PHP");

        fieldDepartment.setBackground(new java.awt.Color(181, 168, 213));
        fieldDepartment.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldDepartment.setForeground(new java.awt.Color(255, 255, 255));

        label7.setBackground(new java.awt.Color(77, 85, 204));
        label7.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label7.setForeground(new java.awt.Color(255, 255, 255));
        label7.setText("Position:");

        labelID.setBackground(new java.awt.Color(77, 85, 204));
        labelID.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        labelID.setForeground(new java.awt.Color(255, 255, 255));
        labelID.setText("N/A");

        jLabel6.setBackground(new java.awt.Color(77, 85, 204));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("ID: ");

        fieldPosition.setBackground(new java.awt.Color(181, 168, 213));
        fieldPosition.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldPosition.setForeground(new java.awt.Color(255, 255, 255));

        fieldSex.setBackground(new java.awt.Color(181, 168, 213));
        fieldSex.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldSex.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setBackground(new java.awt.Color(77, 85, 204));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Edit Employee");

        label16.setBackground(new java.awt.Color(77, 85, 204));
        label16.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label16.setForeground(new java.awt.Color(255, 255, 255));
        label16.setText("Birthdate (MM/dd/yyyy):");

        label8.setBackground(new java.awt.Color(77, 85, 204));
        label8.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        label8.setForeground(new java.awt.Color(255, 255, 255));
        label8.setText("Pay/Hr:");

        fieldDate.setBackground(new java.awt.Color(181, 168, 213));
        fieldDate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldDate.setForeground(new java.awt.Color(255, 255, 255));

        fieldSalary.setBackground(new java.awt.Color(181, 168, 213));
        fieldSalary.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldSalary.setForeground(new java.awt.Color(255, 255, 255));

        jLabel3.setBackground(new java.awt.Color(77, 85, 204));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Rates");

        jLabel4.setBackground(new java.awt.Color(77, 85, 204));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tax Fixed (₱)");

        fieldTaxF1.setBackground(new java.awt.Color(181, 168, 213));
        fieldTaxF1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldTaxF1.setForeground(new java.awt.Color(255, 255, 255));

        fieldTaxF3.setBackground(new java.awt.Color(181, 168, 213));
        fieldTaxF3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldTaxF3.setForeground(new java.awt.Color(255, 255, 255));

        fieldTaxF2.setBackground(new java.awt.Color(181, 168, 213));
        fieldTaxF2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldTaxF2.setForeground(new java.awt.Color(255, 255, 255));

        fieldTaxC1.setBackground(new java.awt.Color(181, 168, 213));
        fieldTaxC1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fieldTaxC1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(77, 85, 204));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Tax Constant (1-100)");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(89, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(label6, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(fieldPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(label5, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(fieldAddress2, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(305, 305, 305)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(labelID, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(200, 200, 200)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(286, 286, 286)
                                                .addComponent(fieldTaxC3, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(10, 10, 10))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(fieldTaxC1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(fieldTaxC2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(label10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(label11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(96, 96, 96)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(label13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(label14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(label8, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(label15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(fieldSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(97, 97, 97)
                                        .addComponent(label9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(label12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fieldTaxF1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(fieldTaxF2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(fieldTaxF3, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(20, 20, 20)
                                        .addComponent(btnAddEmployee))))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(label4, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(fieldAddress1, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(fieldSex, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(label16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(fieldDate, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(fieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addGap(56, 56, 56))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelID, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fieldName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(fieldDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(label16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fieldSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(fieldAddress1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(fieldAddress2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fieldDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fieldPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(70, 70, 70)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(label15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(fieldSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(fieldTaxC1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(fieldTaxF1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(label12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(label9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(label10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13)
                                .addComponent(label11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(label13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13)
                                .addComponent(label14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(fieldTaxF2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(fieldTaxF3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(btnAddEmployee))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(fieldTaxC2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13)
                                .addComponent(fieldTaxC3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(label7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

//    String[] basicInfo;
//    String[] occupation;
//    double salary;
//    int[] taxPercentages;
//    double[] taxSpecific;

    
    private void btnAddEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddEmployeeActionPerformed

        if (!(
            fieldName.getText().equalsIgnoreCase("") ||
            fieldSex.getText().equalsIgnoreCase("") ||
            fieldDate.getText().equalsIgnoreCase("") ||
            fieldAddress1.getText().equalsIgnoreCase("") ||
            fieldAddress2.getText().equalsIgnoreCase("") ||
            fieldDepartment.getText().equalsIgnoreCase("") ||
            fieldPosition.getText().equalsIgnoreCase("") ||
            fieldTaxC1.getText().equalsIgnoreCase("") ||
            fieldTaxC2.getText().equalsIgnoreCase("") ||
            fieldTaxC3.getText().equalsIgnoreCase("") ||
            fieldTaxF1.getText().equalsIgnoreCase("") ||
            fieldTaxF2.getText().equalsIgnoreCase("") ||
            fieldTaxF3.getText().equalsIgnoreCase("") ||
            fieldSalary.getText().equalsIgnoreCase("")

        )) {
            try {
                //            basicInfo[0] = fieldName.getText();
                //            basicInfo[1] = fieldSex.getText();
                //            basicInfo[2] = fieldDate.getText();
                //            basicInfo[3] = fieldAddress1.getText();
                //            basicInfo[4] = fieldAddress2.getText();

                LocalDate currentdate = LocalDate.now();

                //            occupation[0] = fieldDepartment.getText();
                //            occupation[1] = fieldPosition.getText();
                //            occupation[2] = String.valueOf(currentdate);
                //
                //            taxPercentages[0] = Integer.parseInt(fieldTaxC1.getText());
                //            taxPercentages[1] = Integer.parseInt(fieldTaxC2.getText());
                //            taxPercentages[2] = Integer.parseInt(fieldTaxC3.getText());
                //
                //            taxSpecific[0] = Double.parseDouble(fieldTaxF1.getText());
                //            taxSpecific[1] = Double.parseDouble(fieldTaxF2.getText());
                //            taxSpecific[2] = Double.parseDouble(fieldTaxF3.getText());

                //            salary = Double.parseDouble(fieldSalary.getText());

                //            Employee employee = new Employee(salary, taxPercentages, taxSpecific, basicInfo, occupation);

                pst_basic = con.prepareStatement("""
                    UPDATE
                    employee_basic
                    SET
                    employee_name = ?,
                    employee_sex = ?,
                    employee_bdate = ?,
                    employee_address1 = ?,
                    employee_address2 = ?
                    WHERE
                    employee_basic.employee_id = ?""");
                    pst_basic.setString(1, fieldName.getText());
                    pst_basic.setString(2, fieldSex.getText());
                    pst_basic.setString(3, fieldDate.getText());
                    pst_basic.setString(4, fieldAddress1.getText());
                    pst_basic.setString(5, fieldAddress2.getText());
                    pst_basic.setInt(6, id);

                    pst_rates = con.prepareStatement("""
                        UPDATE
                        employee_rates
                        SET
                        employee_salary = ?,
                        tax_percentage1 = ?,
                        tax_percentage2 = ?,
                        tax_percentage3 = ?,
                        tax_fixed1 = ?,
                        tax_fixed2 = ?,
                        tax_fixed3 = ?
                        WHERE
                        employee_rates.employee_id = ?""");
                        pst_rates.setDouble(1, Double.parseDouble(fieldSalary.getText()));
                        pst_rates.setInt(2, Integer.parseInt(fieldTaxC1.getText()));
                        pst_rates.setInt(3, Integer.parseInt(fieldTaxC2.getText()));
                        pst_rates.setInt(4, Integer.parseInt(fieldTaxC3.getText()));
                        pst_rates.setDouble(5, Double.parseDouble(fieldTaxF1.getText()));
                        pst_rates.setDouble(6, Double.parseDouble(fieldTaxF2.getText()));
                        pst_rates.setDouble(7, Double.parseDouble(fieldTaxF3.getText()));
                        pst_rates.setInt(8, id);

                        pst_occupation = con.prepareStatement("""
                            UPDATE
                            employee_occupation
                            SET
                            employee_department = ?,
                            employee_position = ?,
                            employee_hiredDate = ?
                            WHERE
                            employee_occupation.employee_id = ?""");
                            pst_occupation.setString(1, fieldDepartment.getText());
                            pst_occupation.setString(2, fieldPosition.getText());
                            pst_occupation.setString(3, String.valueOf(currentdate));
                            pst_occupation.setInt(4, id);

                            int a = pst_basic.executeUpdate();
                            int b = pst_rates.executeUpdate();
                            int c = pst_occupation.executeUpdate();

                            boolean addVerify = (a == 1)&&(b == 1)&&(c == 1);

                            if(addVerify) {
                                JOptionPane.showMessageDialog(this, "Edit Successfully");
                            } else {
                                JOptionPane.showMessageDialog(this, "Failed");
                            }

                        } catch (SQLException ex) {
                            Logger.getLogger(editEmployee.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        close();
                    } else {
                        JOptionPane.showMessageDialog(this, "Please fill in all the text fields.");
                    }
                    EmployeeInformation EI = new EmployeeInformation(id);
                    EI.refresh();

    }//GEN-LAST:event_btnAddEmployeeActionPerformed

    private void fieldNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNameActionPerformed

    

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new editEmployee().setVisible(true);
            }
        });
    }
    
    //faustino

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddEmployee;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.ButtonGroup buttonGroup6;
    private javax.swing.ButtonGroup buttonGroup7;
    private javax.swing.ButtonGroup buttonGroup8;
    private javax.swing.ButtonGroup buttonGroup9;
    private javax.swing.JTextField fieldAddress1;
    private javax.swing.JTextField fieldAddress2;
    private javax.swing.JTextField fieldDate;
    private javax.swing.JTextField fieldDepartment;
    private javax.swing.JTextField fieldName;
    private javax.swing.JTextField fieldPosition;
    private javax.swing.JTextField fieldSalary;
    private javax.swing.JTextField fieldSex;
    private javax.swing.JTextField fieldTaxC1;
    private javax.swing.JTextField fieldTaxC2;
    private javax.swing.JTextField fieldTaxC3;
    private javax.swing.JTextField fieldTaxF1;
    private javax.swing.JTextField fieldTaxF2;
    private javax.swing.JTextField fieldTaxF3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSpinner jSpinner1;
    private java.awt.Label label1;
    private java.awt.Label label10;
    private java.awt.Label label11;
    private java.awt.Label label12;
    private java.awt.Label label13;
    private java.awt.Label label14;
    private java.awt.Label label15;
    private java.awt.Label label16;
    private java.awt.Label label2;
    private java.awt.Label label4;
    private java.awt.Label label5;
    private java.awt.Label label6;
    private java.awt.Label label7;
    private java.awt.Label label8;
    private java.awt.Label label9;
    private javax.swing.JLabel labelID;
    // End of variables declaration//GEN-END:variables
}
