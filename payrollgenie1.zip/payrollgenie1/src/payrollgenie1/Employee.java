
package payrollgenie1;

public class Employee {
    
    int id;
    String name, sex, birthDate, address1, address2, dept, hiredDate, position;
    double salary;
    int[] taxPercentages;
    double[] taxSpecific;
    
    Employee(
            double salary,  
            int[] taxPercentages,
            double[] taxSpecific,
            String[] basicInfo, 
            String[] occupation
    ) {
            //dapat sunod sunod pag ginawan na obj
            
//        this.id = id;
        
        this.salary = salary;
   
        this.taxPercentages = taxPercentages;
        this.taxSpecific = taxSpecific;
        
        this.name = basicInfo[0];
        this.sex = basicInfo[1];
        this.birthDate = basicInfo[2];
        this.address1 = basicInfo[3];
        this.address2 = basicInfo[4];
        
        this.dept = occupation[0];
        this.position = occupation[1];
        this.hiredDate = occupation[2];
        
    }
    
    int getId() {
        return id;
    }

}
